package com.oukantanata.ouescaperoute.auth

enum class SocialPlatform {
    FACEBOOK, INSTAGRAM, TWITTER_X, TIKTOK, YOUTUBE, SNAPCHAT
}

data class AuthorizedAccount(
    val platform: SocialPlatform,
    val providerAccountId: String,
    val displayName: String,
    val accessToken: String
)

interface SocialAuthProvider {
    suspend fun beginAuthorization(platform: SocialPlatform): Result<AuthorizedAccount>
}
