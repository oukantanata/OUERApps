package com.oukantanata.ouescaperoute.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import java.security.MessageDigest
import java.security.SecureRandom

class SecureStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        "ou_escape_route_secure",
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context.applicationContext,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("pin_hash", digest(pin, salt))
            .putString("pin_salt", salt.toHex())
            .apply()
    }

    fun hasPin(): Boolean = prefs.contains("pin_hash") && prefs.contains("pin_salt")

    fun verifyPin(pin: String): Boolean {
        val hash = prefs.getString("pin_hash", null) ?: return false
        val salt = prefs.getString("pin_salt", null)?.hexToBytes() ?: return false
        return MessageDigest.isEqual(
            hash.toByteArray(Charsets.UTF_8),
            digest(pin, salt).toByteArray(Charsets.UTF_8)
        )
    }

    private fun digest(pin: String, salt: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(salt + pin.toByteArray(Charsets.UTF_8)).toHex()
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
