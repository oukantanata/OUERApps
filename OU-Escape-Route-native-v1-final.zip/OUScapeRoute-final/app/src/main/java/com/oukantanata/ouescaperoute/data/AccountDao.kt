package com.oukantanata.ouescaperoute.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM social_accounts ORDER BY platform, displayName")
    fun observeAll(): Flow<List<Account>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(account: Account)

    @Query("DELETE FROM social_accounts")
    suspend fun deleteAll()
}
