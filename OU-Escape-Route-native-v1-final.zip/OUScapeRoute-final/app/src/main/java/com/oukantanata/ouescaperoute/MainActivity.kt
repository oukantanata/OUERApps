package com.oukantanata.ouescaperoute

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.*
import com.oukantanata.ouescaperoute.data.Account
import com.oukantanata.ouescaperoute.data.AppDatabase
import com.oukantanata.ouescaperoute.security.SecureStore
import com.oukantanata.ouescaperoute.security.UnlockPolicy
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(com.oukantanata.ouescaperoute.R.style.Theme_OUEscapeRoute_Starting)
        installSplashScreen()
        super.onCreate(savedInstanceState)

        val db = AppDatabase.get(this)
        val secure = SecureStore(this)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = androidx.compose.ui.graphics.Color(0xFF00D9FF),
                    secondary = androidx.compose.ui.graphics.Color(0xFFFF20D5),
                    background = androidx.compose.ui.graphics.Color(0xFF05051A),
                    surface = androidx.compose.ui.graphics.Color(0xFF10133A)
                )
            ) {
                AppRoot(db, secure)
            }
        }
    }
}

private data class Game(val name: String, val description: String)

@Composable
private fun AppRoot(db: AppDatabase, secure: SecureStore) {
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    val accounts by db.accountDao().observeAll().collectAsState(initial = emptyList())
    var unlocked by remember { mutableStateOf(false) }
    val policy = remember { UnlockPolicy() }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onGames = { nav.navigate("games") },
                onAccounts = { nav.navigate("accounts") },
                onStore = { nav.navigate("store") },
                onSettings = { nav.navigate("settings") }
            )
        }
        composable("games") {
            Page("Game Hub", nav) {
                val games = listOf(
                    Game("Puzzle Quest", "Solve the route and escape."),
                    Game("Racing Rush", "Fast arcade racing challenge."),
                    Game("Bubble Blast", "Match colorful bubbles."),
                    Game("Tower Defense", "Protect the route."),
                    Game("Space Invaders", "Classic arcade action."),
                    Game("Fruit Slice", "Slice fruit and score points.")
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(games) { game ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text(game.name, style = MaterialTheme.typography.titleLarge)
                                Text(game.description)
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = {}) { Text("Play") }
                            }
                        }
                    }
                }
            }
        }
        composable("accounts") {
            AccountsScreen(
                accounts = if (unlocked) accounts else emptyList(),
                hasPin = secure.hasPin(),
                unlocked = unlocked,
                onUnlock = { pin ->
                    if (!secure.hasPin()) return@AccountsScreen
                    if (policy.canTry() && secure.verifyPin(pin)) {
                        policy.reset()
                        unlocked = true
                    } else if (policy.canTry()) {
                        policy.recordFailure()
                    }
                },
                onAdd = { platform, name, ref ->
                    scope.launch {
                        db.accountDao().insert(
                            Account(
                                platform = platform,
                                displayName = name,
                                accountRef = ref,
                                token = "OAUTH_TOKEN_TO_BE_PROVISIONED"
                            )
                        )
                    }
                },
                onClear = {
                    scope.launch { db.accountDao().deleteAll() }
                    unlocked = false
                },
                nav = nav
            )
        }
        composable("settings") {
            SettingsScreen(
                nav = nav,
                hasPin = secure.hasPin(),
                onSetPin = { secure.setPin(it) },
                onClear = {
                    scope.launch { db.accountDao().deleteAll() }
                    unlocked = false
                }
            )
        }
        composable("store") {
            StoreScreen(nav)
        }
    }
}

@Composable
private fun HomeScreen(
    onGames: () -> Unit,
    onAccounts: () -> Unit,
    onStore: () -> Unit,
    onSettings: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("OU Escape Route") }) }
    ) { p ->
        Column(
            Modifier.padding(p).padding(20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Play • Connect • Explore", style = MaterialTheme.typography.titleMedium)
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Game Hub", style = MaterialTheme.typography.headlineSmall)
                    Text("Your games are the main experience.")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onGames) { Text("Open Game Hub") }
                }
            }
            Button(onClick = onAccounts, modifier = Modifier.fillMaxWidth()) {
                Text("Social Accounts")
            }
            OutlinedButton(onClick = onStore, modifier = Modifier.fillMaxWidth()) {
                Text("Mini App Store")
            }
            OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) {
                Text("Settings")
            }
        }
    }
}

@Composable
private fun AccountsScreen(
    accounts: List<Account>,
    hasPin: Boolean,
    unlocked: Boolean,
    onUnlock: (String) -> Unit,
    onAdd: (String, String, String) -> Unit,
    onClear: () -> Unit,
    nav: NavHostController
) {
    var pin by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("Facebook") }
    var name by remember { mutableStateOf("") }
    var ref by remember { mutableStateOf("") }

    Page("Social Accounts", nav) {
        if (!unlocked) {
            Text("Your saved accounts are hidden until you unlock the private vault.")
            if (!hasPin) {
                Text("No Premium / Pro PIN is configured. Open Settings to create one.")
                Button(onClick = { nav.navigate("settings") }) { Text("Set Premium / Pro PIN") }
            } else {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 12) pin = it },
                    label = { Text("Premium / Pro PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { onUnlock(pin) }, enabled = pin.isNotBlank()) {
                    Text("Unlock Accounts")
                }
            }
        } else {
            Text("Connected-account vault")
            Text("Facebook • Instagram • Twitter/X • TikTok • YouTube • Snapchat")
            OutlinedTextField(platform, { platform = it }, label = { Text("Platform") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(name, { name = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(ref, { ref = it }, label = { Text("Account identifier") }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = {
                    onAdd(platform.trim(), name.trim(), ref.trim())
                    name = ""
                    ref = ""
                },
                enabled = name.isNotBlank() && ref.isNotBlank()
            ) { Text("Save Account") }

            accounts.forEach { account ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(account.platform, style = MaterialTheme.typography.titleMedium)
                        Text(account.displayName)
                        Text(account.accountRef)
                    }
                }
            }
            OutlinedButton(onClick = onClear) { Text("Erase All Saved Accounts") }
        }
    }
}

@Composable
private fun SettingsScreen(
    nav: NavHostController,
    hasPin: Boolean,
    onSetPin: (String) -> Unit,
    onClear: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    Page("Settings", nav) {
        Text("Premium / Pro", style = MaterialTheme.typography.titleLarge)
        Text(if (hasPin) "A local Premium / Pro PIN is configured." else "Create a PIN to protect saved social accounts.")
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 12) pin = it },
            label = { Text(if (hasPin) "Change PIN" else "Create PIN") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { onSetPin(pin); pin = "" },
            enabled = pin.length >= 4
        ) { Text(if (hasPin) "Update PIN" else "Save PIN") }

        Spacer(Modifier.height(12.dp))
        Text("Account Manager", style = MaterialTheme.typography.titleLarge)
        OutlinedButton(onClick = { nav.navigate("accounts") }) { Text("Manage Social Accounts") }
        OutlinedButton(onClick = onClear) { Text("Clear All Saved Accounts") }
    }
}

@Composable
private fun StoreScreen(nav: NavHostController) {
    Page("Mini App Store", nav) {
        Text("Native catalog for games and apps.")
        listOf("Puzzle Quest", "Racing Rush", "Bubble Blast", "Tower Defense").forEach { name ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(name, style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(onClick = {}) { Text("Add") }
                }
            }
        }
        Text("APK installation must use Android's supported package-install flow and user/system approval.")
    }
}

@Composable
private fun Page(title: String, nav: NavHostController, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { TextButton(onClick = { nav.popBackStack() }) { Text("Back") } }
            )
        }
    ) { p ->
        Column(
            Modifier.padding(p).padding(20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}
